Models come from http://people.sc.fsu.edu/~jburkardt/data/obj/obj.html
